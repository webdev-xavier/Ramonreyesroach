const photoInput = document.getElementById('photoInput');
const previewContainer = document.getElementById('previewContainer');

photoInput.addEventListener('change', (event) => {
    const file = event.target.files[0];
    previewContainer.innerHTML = '';

    if (file) {
        const img = document.createElement('img');
        img.src = URL.createObjectURL(file);
        previewContainer.appendChild(img);
    } else {
        previewContainer.innerHTML = '<p>No photo selected</p>';
    }
});
